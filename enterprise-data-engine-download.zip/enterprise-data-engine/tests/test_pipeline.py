from pipeline import normalize, report

def test_normalize():
    assert normalize([{"date":"2023","value":5},{"date":"2022","value":None},{"date":"2023","value":5}]) == [(2023,5.0)]

def test_report(tmp_path):
    target = tmp_path / "report.html"
    report([(2023,100.0)], str(target))
    assert "2023" in target.read_text()
